import tkinter as tk
from math import log
class GUI:
	root = None
	InputEntry = None
	InputStr = None
	OutputLabel = None
	OutputProb = None
	rnn = None
	@staticmethod
	def Init():
		GUI.root = tk.Tk()
		GUI.root.title('Password Evaluation')
		GUI.root.resizable(False,False)
		GUI.root.geometry('300x80+600+300')
		GUI.AddInputEntry()
		GUI.AddOutputLabel()
		GUI.root.mainloop()
	@staticmethod
	def AddInputEntry():
		GUI.InputStr = tk.StringVar()
		GUI.InputEntry = tk.Entry(GUI.root,textvariable=GUI.InputStr).place(x=70,y=20)

	@staticmethod
	def AddOutputLabel():
		GUI.OutputProb = tk.IntVar(0.00)
		GUI.OutputLabel = tk.Label(GUI.root,text='Probability',textvariable=GUI.OutputProb)
		GUI.OutputLabel.place(x=220, y=20)
		GUI.root.bind("<Return>",GUI.SetOutput)
	@staticmethod
	def SetOutput(_):
		if len(GUI.InputStr.get()) < 8 or len(GUI.InputStr.get()) > 16:
			GUI.OutputProb.set("Invalid Input")
		else:
			result = round(log(GUI.rnn.TestPwdProb(GUI.InputStr.get()), 10), 2)
			GUI.OutputProb.set(result)
