class Data:
	BatchLocation = 0
	DataLines = []
	batches = []
	batch_size = 8

	@staticmethod
	def space(num):
		result = ""
		for i in range(num):
			result = result + " "
		return result
	@staticmethod
	def Pwd2Batch(password,max_len): # input: like "01234567",max_len = 8
		# X = [[0],[0,1],[0,1,2],[0,1,2,3],[0,1,2,3,4],[0,1,2,3,4,5],[0,1,2,3,4,5,6],[0,1,2,3,4,5,6,7]]
		# Y = [[1],[1,2],[0,1,2],[0,1,2,3],[0,1,2,3,4],[0,1,2,3,4,5],[0,1,2,3,4,5,6],[0,1,2,3,4,5,6,7,E]]
		X = []
		Y = []
		for i in range(1,max_len):
			X.append(password[0:i] + Data.space(max_len - i))
			Y.append(password[1:i + 1] + Data.space(max_len - i))
		X.append(password[0:max_len])
		Y.append(password[1:max_len+1])
		return X,Y

	@staticmethod
	def GetCharsSet():
		letters = list(" abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
		numbers = list("0123456789")
		symbols = list("~!@#$%^&*()_+{}|:<>?[]\;',./=-`\"")
		special = list("«")
		result = letters + numbers + symbols + special
		return result
