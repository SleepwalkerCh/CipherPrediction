#coding=utf-8

from numpy import sum
from numpy import exp
from numpy import reshape
from tensorflow import nn
from tensorflow import placeholder

from tensorflow import one_hot
from tensorflow import ones
from tensorflow import reshape
from tensorflow.contrib.layers import fully_connected
from tensorflow.contrib.seq2seq import sequence_loss
from tensorflow.python.ops.math_ops import reduce_mean
from tensorflow.python.training.adam import AdamOptimizer
from tensorflow.python.training.saver import Saver
from tensorflow.python.client.session import Session
from tensorflow.python.framework.dtypes import float32
from tensorflow.python.framework.dtypes import int32
from tensorflow.python.framework.random_seed import set_random_seed
from Src.FirstCharProb import FirstCharProb
from Src.Data import Data


class RNN:
	batch_size = 8  # one sample Data, one batch
	max_sequence_length = 8
	tensorboard_route = "D:/logs"
	is_new_train = True
	total_step = 0
	def LstmCell(self,hidden_size):
		# LSTM cell
		lstm_cell = nn.rnn_cell.BasicLSTMCell(hidden_size, forget_bias=1.0, state_is_tuple=True)
		# Dropout Layer
		lstm_cell = nn.rnn_cell.DropoutWrapper(cell=lstm_cell, input_keep_prob=1.0, output_keep_prob=1.0)
		return lstm_cell
	def CreateNetwork(self):
		set_random_seed(777)  # reproducibility
		idx2char = Data.GetCharsSet()
		# hyper parameters
		hidden_size = 80  # RNN output size
		num_classes = len(idx2char)  # final output size (RNN or softmax, etc.)
		learning_rate = 0.001
		layer_num = 1

		self.X = placeholder(int32, [RNN.batch_size, RNN.max_sequence_length])  # X Data
		self.Y = placeholder(int32, [RNN.batch_size, RNN.max_sequence_length])  # Y label

		x_one_hot = one_hot(self.X, num_classes)  # one hot: 1 -> 0 1 0 0 0 0 0 0 0 0
		# LSTM cell
		lstm_cell = nn.rnn_cell.BasicLSTMCell(hidden_size, forget_bias=1.0, state_is_tuple=True)
		# Dropout Layer
		lstm_cell = nn.rnn_cell.DropoutWrapper(cell=lstm_cell, input_keep_prob=1.0, output_keep_prob=1.0)
		# multi-LSTM cell
		mlstm_cell = nn.rnn_cell.MultiRNNCell([self.LstmCell(hidden_size) for _ in range(layer_num)], state_is_tuple=True)

		init_state = mlstm_cell.zero_state(batch_size=RNN.batch_size, dtype=float32)
		x_length = [1,2,3,4,5,6,7,8]
		outputs,_state = nn.dynamic_rnn(mlstm_cell, inputs=x_one_hot,sequence_length=x_length,initial_state=init_state, dtype=float32, time_major=False)
		# FC layer1
		X_for_fc1 = reshape(outputs, [-1, hidden_size])
		outputs = fully_connected(X_for_fc1, num_classes, activation_fn=None)
		# FC layer2
		#outputs = tf.contrib.layers.fully_connected(outputs, num_classes, activation_fn=None)
		# reshape out for sequence_loss
		self.outputs = reshape(outputs, [RNN.batch_size, -1, num_classes])

		weights = ones([RNN.batch_size, RNN.max_sequence_length])
		# http://blog.csdn.net/appleml/article/details/54017873
		self.loss = reduce_mean(sequence_loss(logits=self.outputs, targets=self.Y, weights=weights))
		self.train = AdamOptimizer(learning_rate=learning_rate).minimize(self.loss)
		self.sess = Session()

	def LoadModel(self):
		saver = Saver(max_to_keep=1)
		saver.restore(sess=self.sess, save_path="../Model/model.ckpt")

	def softmax(self,x):
		return exp(x) / sum(exp(x), axis=0)
	def ProbSoftMax(self,Probability):
		for i in range(RNN.batch_size):
			for j in range(RNN.max_sequence_length):
				Probability[i][j] = self.softmax(Probability[i][j]).tolist()
		return Probability

	def TestPwdProb(self, TestString): # Calculate the probability of a certain Test String
		# if its length is equal to RNN.batch_size, calculate directly
		# if larger, calculate first bach_size and then multiply the other locations
		if TestString.__contains__('«') == False:
			TestString = TestString + '«'

		# preparation
		idx2char = Data.GetCharsSet()
		char2idx = {c: i for i, c in enumerate(idx2char)}
		Overlen = len(TestString) - RNN.batch_size - 1
		MaxTimes = 10 ** 50
		# Initial Calculate
		x_data,y_data = Data.Pwd2Batch(TestString,RNN.max_sequence_length)
		x_idx = [[char2idx[c] for c in x_data[k]] for k in range(RNN.max_sequence_length)]
		result = FirstCharProb.GetProb(TestString[0])
		# take the first batch_size locaitons into the RNN
		Probability = self.sess.run(self.outputs, feed_dict={self.X: x_idx})
		Probability = self.ProbSoftMax(Probability.tolist()) # change into a good format
		# display the predicted characters
		# for i in range(RNN.batch_size):
		# 	for j in range(RNN.max_sequence_length):
		# 		print(idx2char[Probability[i][j].index(max(Probability[i][j]))],end='')
		# 	print("",end=" ")
		# multiply all first locations
		for i in range(RNN.max_sequence_length):
			result = result * Probability[i][i][char2idx[TestString[i + 1]]]
		if Overlen == 0: # only has the size of batch_size
			if result == 0:
				return MaxTimes
			return 1/result
		# over-long part calculation
		NextString = TestString[Overlen:len(TestString)]
		x_data, y_data = Data.Pwd2Batch(NextString, RNN.max_sequence_length)
		x_idx = [[char2idx[c] for c in x_data[k]] for k in range(RNN.max_sequence_length)]

		Probability = self.sess.run(self.outputs, feed_dict={self.X: x_idx})
		Probability = Probability.tolist()
		Probability = self.ProbSoftMax(Probability)

		for i in range(Overlen):
			result = result * Probability[RNN.max_sequence_length - i - 1]\
											[RNN.max_sequence_length - i - 1]\
											[char2idx[NextString[RNN.max_sequence_length- i]]]
		if result == 0:
			return MaxTimes
		return 1/result
