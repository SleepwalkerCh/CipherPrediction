from Src.LSTM import RNN
from math import log
from sys import argv
from os import environ

def Main():
	environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
	if len(argv) < 2:
		print("Usgae: Program paasword")
		return
	if len(argv[1]) < 8 or len(argv[1]) > 16:
		print("The length must be between 8 and 16")
		return

	rnn = RNN()
	rnn.CreateNetwork()
	rnn.LoadModel()
	result = round(log(rnn.TestPwdProb(argv[1]),10),2)
	print(result)

Main()
