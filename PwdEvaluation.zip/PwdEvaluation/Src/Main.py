from Src.LSTM import RNN

from sys import argv
from os import environ
from Src.GUI import GUI

def Main():
	environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
	# if len(argv) < 2:
	# 	print("Usgae: Program paasword")
	# 	return
	# if len(argv[1]) < 8 or len(argv[1]) > 16:
	# 	print("The length must be between 8 and 16")
	# 	return

	rnn = RNN()
	rnn.CreateNetwork()
	rnn.LoadModel()
	GUI.rnn = rnn
	GUI.Init()


Main()
